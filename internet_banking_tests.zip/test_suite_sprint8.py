# test_suite_sprint8.py
# Suite real, executavel, usada para VALIDAR o comportamento do app.py/app2.py
# antes de qualquer especificacao ser escrita no caderno 29119-3.
#
# Ambiente sandbox sem acesso a rede -> usa unittest (biblioteca padrao) em vez
# de pytest, mas os asserts e a logica de teste sao equivalentes. O Flask test
# client é usado para chamar a aplicacao diretamente, sem precisar de um
# servidor HTTP rodando (mesmo mecanismo que pytest + Flask test client usariam).

import os
import unittest
import importlib
import sys


class InternetBankingTestCase(unittest.TestCase):

    def setUp(self):
        # Banco de dados isolado por teste para evitar contaminacao entre casos
        self.db_path = f"test_banking_{self.id().split('.')[-1]}.db"
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

        # Recarrega o modulo app a cada teste para resetar o estado do Flask config
        if "app" in sys.modules:
            del sys.modules["app"]
        import app as app_module
        self.app_module = app_module
        app_module.app.config["DATABASE"] = self.db_path
        app_module.app.config["TESTING"] = True
        app_module.init_db()
        self.client = app_module.app.test_client()

    def tearDown(self):
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    # ---------- GET /saldo/<conta_id> ----------

    def test_saldo_conta_existente_retorna_200(self):
        resp = self.client.get("/saldo/1")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["conta_id"], 1)
        self.assertEqual(data["titular"], "Alice")
        self.assertEqual(data["saldo"], 1000.00)

    def test_saldo_conta_inexistente_retorna_404(self):
        resp = self.client.get("/saldo/999")
        self.assertEqual(resp.status_code, 404)
        self.assertEqual(resp.get_json()["erro"], "Conta nao encontrada")

    # ---------- POST /transferencia ----------

    def test_transferencia_valida_retorna_200_e_atualiza_saldos(self):
        resp = self.client.post("/transferencia", json={"origem": 1, "destino": 2, "valor": 100.0})
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["mensagem"], "Transferencia realizada")
        self.assertEqual(data["valor"], 100.0)

        saldo_origem = self.client.get("/saldo/1").get_json()["saldo"]
        saldo_destino = self.client.get("/saldo/2").get_json()["saldo"]
        self.assertEqual(saldo_origem, 900.00)
        self.assertEqual(saldo_destino, 600.00)

    def test_transferencia_corpo_ausente_retorna_400(self):
        resp = self.client.post("/transferencia", data="", content_type="application/json")
        self.assertEqual(resp.status_code, 400)
        self.assertEqual(resp.get_json()["erro"], "Corpo da requisicao invalido ou ausente")

    def test_transferencia_campo_faltante_retorna_400(self):
        resp = self.client.post("/transferencia", json={"origem": 1, "destino": 2})
        self.assertEqual(resp.status_code, 400)
        self.assertIn("Campos obrigatorios ausentes", resp.get_json()["erro"])

    def test_transferencia_valor_negativo_retorna_422(self):
        resp = self.client.post("/transferencia", json={"origem": 1, "destino": 2, "valor": -50})
        self.assertEqual(resp.status_code, 422)
        self.assertEqual(resp.get_json()["erro"], "Valor deve ser positivo")

    def test_transferencia_valor_zero_retorna_422(self):
        resp = self.client.post("/transferencia", json={"origem": 1, "destino": 2, "valor": 0})
        self.assertEqual(resp.status_code, 422)
        self.assertEqual(resp.get_json()["erro"], "Valor deve ser positivo")

    def test_transferencia_origem_igual_destino_retorna_422(self):
        resp = self.client.post("/transferencia", json={"origem": 1, "destino": 1, "valor": 50})
        self.assertEqual(resp.status_code, 422)
        self.assertEqual(resp.get_json()["erro"], "Origem e destino nao podem ser iguais")

    def test_transferencia_conta_inexistente_retorna_404(self):
        resp = self.client.post("/transferencia", json={"origem": 1, "destino": 999, "valor": 50})
        self.assertEqual(resp.status_code, 404)
        self.assertEqual(resp.get_json()["erro"], "Conta nao encontrada")

    def test_transferencia_saldo_insuficiente_retorna_422(self):
        resp = self.client.post("/transferencia", json={"origem": 3, "destino": 1, "valor": 50})
        self.assertEqual(resp.status_code, 422)
        data = resp.get_json()
        self.assertEqual(data["erro"], "Saldo insuficiente")
        self.assertEqual(data["saldo_atual"], 0.00)

    def test_transferencia_valor_string_retorna_422(self):
        # valor nao numerico -> cai no isinstance check, nao no campo ausente
        resp = self.client.post("/transferencia", json={"origem": 1, "destino": 2, "valor": "100"})
        self.assertEqual(resp.status_code, 422)
        self.assertEqual(resp.get_json()["erro"], "Valor deve ser positivo")

    # ---------- GET /extrato/<conta_id> ----------

    def test_extrato_conta_existente_sem_movimentacao(self):
        resp = self.client.get("/extrato/3")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertEqual(data["titular"], "Carlos")
        self.assertEqual(data["historico"], [])

    def test_extrato_conta_inexistente_retorna_404(self):
        resp = self.client.get("/extrato/999")
        self.assertEqual(resp.status_code, 404)

    def test_extrato_reflete_transferencia_realizada(self):
        self.client.post("/transferencia", json={"origem": 1, "destino": 2, "valor": 200.0})
        resp = self.client.get("/extrato/1")
        data = resp.get_json()
        self.assertEqual(len(data["historico"]), 1)
        self.assertEqual(data["historico"][0]["origem"], 1)
        self.assertEqual(data["historico"][0]["destino"], 2)
        self.assertEqual(data["historico"][0]["valor"], 200.0)

    def test_extrato_lista_tanto_envios_quanto_recebimentos(self):
        self.client.post("/transferencia", json={"origem": 1, "destino": 2, "valor": 50.0})
        self.client.post("/transferencia", json={"origem": 2, "destino": 1, "valor": 20.0})
        resp = self.client.get("/extrato/1")
        data = resp.get_json()
        self.assertEqual(len(data["historico"]), 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
