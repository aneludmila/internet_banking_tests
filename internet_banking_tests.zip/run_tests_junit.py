# run_tests_junit.py
# Executa a suite real (test_suite_sprint8.py) e produz um report.xml em
# formato JUnit, usando apenas a biblioteca padrao (sem pytest/junit-xml,
# que exigiriam rede neste ambiente). Cada <testcase> reflete o resultado
# REAL da execucao via unittest contra o app.py.

import unittest
import time
import xml.etree.ElementTree as ET
from xml.dom import minidom

from test_suite_sprint8 import InternetBankingTestCase


def run_and_export(output_path="report.xml"):
    test_names = unittest.TestLoader().getTestCaseNames(InternetBankingTestCase)
    suite = unittest.TestSuite(InternetBankingTestCase(name) for name in test_names)

    runner = unittest.TextTestRunner(verbosity=2)
    start = time.time()
    result = runner.run(suite)
    duration = time.time() - start

    fail_map = {t[0]._testMethodName: ("failure", t[1]) for t in result.failures}
    fail_map.update({t[0]._testMethodName: ("error", t[1]) for t in result.errors})

    testsuite_el = ET.Element("testsuite", {
        "name": "test_suite_sprint8.InternetBankingTestCase",
        "tests": str(result.testsRun),
        "failures": str(len(result.failures)),
        "errors": str(len(result.errors)),
        "time": f"{duration:.3f}",
    })

    for name in test_names:
        tc_el = ET.SubElement(testsuite_el, "testcase", {
            "classname": "test_suite_sprint8.InternetBankingTestCase",
            "name": name,
            "time": "0.0",
        })
        if name in fail_map:
            tag, trace = fail_map[name]
            fail_el = ET.SubElement(tc_el, tag, {"message": trace.strip().splitlines()[-1][:200]})
            fail_el.text = trace

    rough = ET.tostring(testsuite_el, encoding="unicode")
    pretty = minidom.parseString(rough).toprettyxml(indent="  ")
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(pretty)

    print(f"\n{result.testsRun} testes executados, {len(result.failures)} falhas, {len(result.errors)} erros.")
    print(f"report.xml gerado em: {output_path}")
    return result


if __name__ == "__main__":
    run_and_export()
