# scripts/gera_matriz.py
# Le o report.xml gerado pela execucao real da suite (run_tests_junit.py)
# e cruza cada caso de teste com:
#   (i)  o ID de caso de teste no caderno ISO/IEC/IEEE 29119-3 (TC-01..TC-04)
#   (ii) o requisito do internet banking ao qual o caso rastreia
#   (iii) o resultado de execucao extraido do report.xml (pass/fail/error)
#
# A tabela de rastreabilidade (requisito <-> caso <-> evidencia) e' o
# mapeamento estatico abaixo; o STATUS de cada linha vem da execucao real,
# nao de um valor fixo. Roda como parte do pipeline CI a cada commit.

import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

REPORT_PATH = "report.xml"

# Mapeamento requisito <-> caso de teste <-> nome do metodo de teste real
# (o nome do metodo de teste e' o elo de evidencia, lido do report.xml)
RASTREABILIDADE = [
    {
        "id_caso": "TC-01",
        "requisito": "RF-01 Consultar saldo de conta existente",
        "metodo_teste": "test_saldo_conta_existente_retorna_200",
    },
    {
        "id_caso": "TC-02",
        "requisito": "RF-02 Rejeitar transferencia com saldo insuficiente",
        "metodo_teste": "test_transferencia_saldo_insuficiente_retorna_422",
    },
    {
        "id_caso": "TC-03",
        "requisito": "RF-03 Rejeitar transferencia entre conta igual (origem = destino)",
        "metodo_teste": "test_transferencia_origem_igual_destino_retorna_422",
    },
    {
        "id_caso": "TC-04",
        "requisito": "RF-04 Refletir transferencia realizada no extrato da conta",
        "metodo_teste": "test_extrato_reflete_transferencia_realizada",
    },
]


def carrega_resultados(report_path):
    """Le o report.xml (JUnit) e retorna {nome_do_teste: status}."""
    try:
        tree = ET.parse(report_path)
    except FileNotFoundError:
        print(f"AVISO: {report_path} nao encontrado. Rode run_tests_junit.py antes.", file=sys.stderr)
        return {}

    root = tree.getroot()
    resultados = {}
    for testcase in root.findall("testcase"):
        nome = testcase.get("name")
        if testcase.find("failure") is not None:
            resultados[nome] = "FALHOU"
        elif testcase.find("error") is not None:
            resultados[nome] = "ERRO"
        else:
            resultados[nome] = "PASSOU"
    return resultados


def gera_markdown(resultados):
    agora = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    linhas = []
    linhas.append("# Matriz de Rastreabilidade — Requisito ↔ Caso de Teste ↔ Evidência")
    linhas.append("")
    linhas.append(f"Gerada automaticamente em: {agora}")
    linhas.append("")
    linhas.append("| ID Caso | Requisito | Método de teste (evidência) | Status real (report.xml) |")
    linhas.append("|---|---|---|---|")

    for item in RASTREABILIDADE:
        status = resultados.get(item["metodo_teste"], "NAO EXECUTADO")
        linhas.append(
            f"| {item['id_caso']} | {item['requisito']} | "
            f"`{item['metodo_teste']}` | {status} |"
        )

    linhas.append("")
    total = len(RASTREABILIDADE)
    passou = sum(1 for item in RASTREABILIDADE if resultados.get(item["metodo_teste"]) == "PASSOU")
    linhas.append(f"**Cobertura de rastreabilidade:** {passou}/{total} requisitos com evidência de execução bem-sucedida.")
    return "\n".join(linhas)


if __name__ == "__main__":
    resultados = carrega_resultados(REPORT_PATH)
    print(gera_markdown(resultados))
