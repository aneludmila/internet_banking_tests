# Matriz de Rastreabilidade — Requisito ↔ Caso de Teste ↔ Evidência

Gerada automaticamente em: 2026-06-23 22:10:10 UTC

| ID Caso | Requisito | Método de teste (evidência) | Status real (report.xml) |
|---|---|---|---|
| TC-01 | RF-01 Consultar saldo de conta existente | `test_saldo_conta_existente_retorna_200` | PASSOU |
| TC-02 | RF-02 Rejeitar transferencia com saldo insuficiente | `test_transferencia_saldo_insuficiente_retorna_422` | PASSOU |
| TC-03 | RF-03 Rejeitar transferencia entre conta igual (origem = destino) | `test_transferencia_origem_igual_destino_retorna_422` | PASSOU |
| TC-04 | RF-04 Refletir transferencia realizada no extrato da conta | `test_extrato_reflete_transferencia_realizada` | PASSOU |

**Cobertura de rastreabilidade:** 4/4 requisitos com evidência de execução bem-sucedida.
